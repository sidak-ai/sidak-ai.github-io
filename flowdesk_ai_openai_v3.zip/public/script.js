// Frontend behaviour: chat UI + transcript upload + calling backend
const chatToggle = document.getElementById('chatToggle');
const chatWindow = document.getElementById('chatWindow');
const closeChat = document.getElementById('closeChat');
const chatForm = document.getElementById('chatForm');
const chatInput = document.getElementById('chatInput');
const messages = document.getElementById('messages');
const transcriptArea = document.getElementById('transcriptArea');
const fileInput = document.getElementById('fileInput');
const clearTranscript = document.getElementById('clearTranscript');

chatToggle.addEventListener('click', () => {
  chatWindow.classList.toggle('hidden');
});
closeChat.addEventListener('click', () => chatWindow.classList.add('hidden'));

function appendMessage(text, who='bot') {
  const div = document.createElement('div');
  div.className = 'msg ' + (who==='user' ? 'user' : 'bot');
  div.innerText = text;
  messages.appendChild(div);
  messages.scrollTop = messages.scrollHeight;
  // also append to transcript area
  transcriptArea.value += (who==='user' ? 'User: ' : 'Bot: ') + text + '\n';
}

// Send chat to backend
chatForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const text = chatInput.value.trim();
  if (!text) return;
  appendMessage(text, 'user');
  chatInput.value = '';
  appendMessage('...', 'bot'); // placeholder
  const lastBot = [...messages.querySelectorAll('.msg.bot')].pop();
  try {
    const res = await fetch('/api/chat', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({message:text})
    });
    if(!res.ok){
      throw new Error('Server error');
    }
    const data = await res.json();
    // replace last bot placeholder
    if(lastBot) lastBot.innerText = data.reply;
    else appendMessage(data.reply,'bot');
  } catch(err){
    if(lastBot) lastBot.innerText = 'Sorry — there was an error. Try again.';
  }
});

// File upload to transcript area (txt only)
fileInput.addEventListener('change', async (e)=>{
  const f = e.target.files[0];
  if(!f) return;
  if(f.type !== '' && !f.type.includes('text')){
    alert('Please upload a .txt file');
    return;
  }
  const text = await f.text();
  transcriptArea.value = text;
});
clearTranscript.addEventListener('click', ()=> transcriptArea.value='');
